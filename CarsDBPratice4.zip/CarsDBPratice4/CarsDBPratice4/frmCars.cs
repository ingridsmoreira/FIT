﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarsDBPratice4
{
    public partial class frmCars : Form
    {
        public frmCars()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hireDataSet.tblCar' table. You can move, or remove it, as needed.
            this.tblCarTableAdapter.Fill(this.hireDataSet.tblCar);

            // Task A your name and today's date
            this.Text = "Task A - Thomas Mc Cann - " + DateTime.Now.ToShortDateString();

            UpdateRecordDisplay();

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveFirst();
            UpdateRecordDisplay();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MovePrevious();
            UpdateRecordDisplay();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveNext();
            UpdateRecordDisplay();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveLast();

            UpdateRecordDisplay();
        }

        // Method to update the record display
        // Add your own comments to explain how this method works
        private void UpdateRecordDisplay()
        {
            txBxRecordDisplay.Text = tblCarBindingSource.Position + 1 + " of " + tblCarBindingSource.Count;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.AddNew(); // All form textboxes cleared
            ckBxAvailable.CheckState = CheckState.Unchecked; // Set as unchecked
            UpdateRecordDisplay();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.CancelEdit();
            UpdateRecordDisplay();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Only remove records if there are records to remove
            // If the Count of records is greater than 0 then there are records
            if (tblCarBindingSource.Count > 0)
            {
                tblCarBindingSource.RemoveCurrent();
                UpdateRecordDisplay();
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Apply any pending changes to the dataset
            tblCarBindingSource.EndEdit();

            // Update the database with any change made to the hireDataSet
            int num_records_updated = tblCarTableAdapter.Update(hireDataSet);

            MessageBox.Show($"Number of records updated: {num_records_updated}");
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // frmSearch searchForm = new frmSearch();

            // Create a new search From using the overoaded constructor
            // that takes a parameter of frmCars reference (this form)
            frmSearch searchForm = new frmSearch(this);

            // Hide this car Form
            this.Hide();

            searchForm.Show();
        }
    }
}
