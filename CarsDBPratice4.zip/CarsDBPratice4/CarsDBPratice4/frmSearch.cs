﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarsDBPratice4
{
    public partial class frmSearch : Form
    {
        // Reference to hold a rewference to the
        // Cars form that opened this form
        private frmCars carsForm;
        public frmSearch()
        {
            InitializeComponent();
        }

        // An overloaded constructor
        public frmSearch(frmCars carsForm)
        {
            InitializeComponent();
            // Save a reference to the car form that opened this
            // search form
            this.carsForm = carsForm;
        }

        private void frmSearch_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hireDataSet.tblCar' table. You can move, or remove it, as needed.
            this.tblCarTableAdapter.Fill(this.hireDataSet.tblCar);

            // Task A - Yout name - todays date
            this.Text = "Task A - Thomas Mc Cann" + DateTime.Now.ToShortDateString();

            // Code to populate the cboField combo box
            cboField.Items.Add("Make");
            cboField.Items.Add("Engine Size");
            cboField.Items.Add("RentalPerDay");
            cboField.Items.Add("DateRegistered");
            cboField.Items.Add("Available");

            // populate cboOperator with the following operator symbols, each one as a 
            // single list item: =, <, >, <=, >=

            cboOperator.Items.Add("=");
            cboOperator.Items.Add("<");
            cboOperator.Items.Add(">");
            cboOperator.Items.Add("<=");
            cboOperator.Items.Add(">=");          

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            // Clsoe this (Search) form and show the Car form.
            this.Close();
            carsForm.Show();
        }

        // Event handler to enusre the carFom to shown again if the user clicks
        // the window close [X] icon.
        private void frmSearch_Closing(object sender, FormClosingEventArgs e)
        {
            carsForm.Show();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {

            if (!String.IsNullOrEmpty(cboField.Text.Trim()) 
                && !String.IsNullOrEmpty(cboOperator.Text.Trim())
                && !String.IsNullOrEmpty(txBxFilterValue.Text.Trim())
                )
            {
                // " [FIELD] operator 'VALUE' "
                string filter = $"[{cboField.Text}] {cboOperator.Text} '{txBxFilterValue.Text}'";

                // Apply the filter the binding source
                tblCarBindingSource.Filter = filter;
            }
            else
            {
                MessageBox.Show("Please check your search criteria.\n\nEnsure all fields have value!");
            }

            
        }
    }
}
