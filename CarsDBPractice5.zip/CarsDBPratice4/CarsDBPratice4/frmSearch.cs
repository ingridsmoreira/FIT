﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarsDBPratice4
{
    public partial class frmSearch : Form
    {
        // A reference to a cars form object
        private frmCars carsForm;
        public frmSearch()
        {
            InitializeComponent();
        }

        // Overloaded constructor that has a parameter of a frmCars reference
        public frmSearch(frmCars carsForm)
        {
            InitializeComponent();
            // Assign the passed in reference to this forms
            // instance field 'carForm'
            this.carsForm = carsForm;
        }

        private void frmSearch_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hireDataSet.tblCar' table. You can move, or remove it, as needed.
            this.tblCarTableAdapter.Fill(this.hireDataSet.tblCar);

            this.Text = "Task A - Thomas Mc Cann - " + DateTime.Now.ToShortDateString();

            // Code to populate the cboField combo box
            cboField.Items.Add("Make");
            cboField.Items.Add("Engine Size");
            cboField.Items.Add("RentalPerDay");
            cboField.Items.Add("DateRegistered");
            cboField.Items.Add("Available");

            // Code to populate the cboOperator combo box
            cboOperator.Items.Add("=");
            cboOperator.Items.Add("<");
            cboOperator.Items.Add(">");
            cboOperator.Items.Add("<=");
            cboOperator.Items.Add(">=");

        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            // The search should be run only if data exists in all three
            // query criteria controls. A criteria string that is not matched by 
            // any record must return nothing.

            // tblCarBindingSource.Filter = "[Engine Size] > '1.6L'";

            // Search should only run if there are values in all three controls
            // If (not false && not false && not false)
            // if (true && true && true)
            if (!String.IsNullOrEmpty(cboField.Text) &&
                !String.IsNullOrEmpty(cboOperator.Text) &&
                !String.IsNullOrEmpty(txBxFilterValue.Text)
                )
            {
                string field = cboField.Text;
                string oper = cboOperator.Text;
                string val = txBxFilterValue.Text.Trim();

                string filter = $"[{field}] {oper} '{val}'";

                tblCarBindingSource.Filter = filter;
            }
            else
            {
                MessageBox.Show("Please check your search criteria.");
                // Reset the Filter to an empty string
                // tblCarBindingSource.Filter = "";
            }
            
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();

            // Show the car form again
            carsForm.Show();                   

        }

        // Ensure the carForm is shown again if the user clicks the form window
        // [X] icon instead fo the close button.
        private void frmSearch_Closing(object sender, FormClosingEventArgs e)
        {
            // Show the car form again
            carsForm.Show();
        }
    }
}
