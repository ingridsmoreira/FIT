﻿using System;
using System.Windows.Forms;

/// <summary>
/// Thomas Mc Cann - 5/1/2021
/// Level 3 Creating an object oriented computer program using C# (7540-039)
/// Task A
/// </summary>

namespace CarsDBPratice4
{
    public partial class frmCars : Form
    {
        public frmCars()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Task A your name and today's date
            this.Text = "Task A - Thomas Mc Cann - " + DateTime.Now.ToShortDateString();

            try
            {
                // TODO: This line of code loads data into the 'hireDataSet.tblCar' table. You can move, or remove it, as needed.
                this.tblCarTableAdapter.Fill(this.hireDataSet.tblCar);
            }
            catch
            {
                MessageBox.Show("Some bad thing happened. Could not connect to database!");
                // Disable the Serach button if there was a problem connecting to the database
                btnSearch.Enabled = false;
            }    

            UpdateRecordDisplay();

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveFirst();
            UpdateRecordDisplay();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MovePrevious();
            UpdateRecordDisplay();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveNext();
            UpdateRecordDisplay();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveLast();

            UpdateRecordDisplay();
        }

        // Method to update the record display
        // Add your own comments to explain how this method works
        private void UpdateRecordDisplay()
        {
            txBxRecordDisplay.Text = tblCarBindingSource.Position + 1 + " of " + tblCarBindingSource.Count;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                tblCarBindingSource.AddNew(); // All form textboxes cleared
                ckBxAvailable.CheckState = CheckState.Unchecked; // Set as unchecked
                UpdateRecordDisplay();
            }
            catch
            {
                MessageBox.Show("Cannot add record to database.");
            }
            
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.CancelEdit();
            UpdateRecordDisplay();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Only remove records if there are records to remove
            // If the Count of records is greater than 0 then there are records
            if (tblCarBindingSource.Count > 0)
            {
                tblCarBindingSource.RemoveCurrent();
                UpdateRecordDisplay();
            }
            
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Apply any pending changes to the dataset
            tblCarBindingSource.EndEdit();

            // Update the database with any change made to the hireDataSet
            int num_records_updated = tblCarTableAdapter.Update(hireDataSet);

            MessageBox.Show($"Number of records updated: {num_records_updated}");
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // Create a new instance of the search form
            // frmSearch searchFrom = new frmSearch();

            // Use th overloaded frmSearch constructor and pass in a reference to
            // this form instance
            frmSearch searchFrom = new frmSearch(this);

            // Show the search form
            searchFrom.Show();

            // Hide this form
            this.Hide();
        }
    }
}
