import datetime

# number of weeks
weeks_in_2021 = 52.149

# Employee tax credit
tax_credit = 1650
# Tax 20% cut-off in 2021
tax_20_cutoff = 35300
# Higher and lower rates
lower_rate = .2
higher_rate = .4

prsi_max_weekly_credit = 12

#employees saved in the system
emp1 = {
    "First name": "Linda",
    "Last name": "Oconnor",
    "PPS": "84569852A",
    "Tax Credit": 1650,
    "PRSI Class": "A",
    "Annual Salary": 20000
}

emp2 = {
    "First name": "Clara",
    "Last name": "McDonald",
    "PPS": "554154483B",
    "Tax Credit": 1852,
    "PRSI Class": "A",
    "Annual Salary": 45000

}
# list with one employee
employees = [emp1]
# Append employee
employees.append(emp2)

# get employee paye tax


def calculate_paye_tax_liabliity(employee):
    # tax due on Salary
    annual_salary = employee["Annual Salary"]
    tax_liability = 0

    # check if de annual salary is higher than the cutoff the libiality is 40%

    if (annual_salary > lower_rate):
        tax_liability += (annual_salary - tax_20_cutoff) * higher_rate
        tax_liability += tax_20_cutoff * lower_rate

    else:
        # 20% of gross salary (tax liability)
        tax_liability += (annual_salary * lower_rate)

    return tax_liability


# Tax duw
# TAX - tax credits includs personal and paye
def calculate_annual_tax_due(employee):
    tax_liability = calculate_paye_tax_liabliity(employee)
    tax_due = tax_liability - \
        (employee["Tax Credit"] + tax_credit)
    return tax_due

#Calculation week employee PRSI
def calculate_week_employee_PRSI_due(employee):
    weekly_salary = employee["Annual Salary"] / weeks_in_2021

    prsi = 0

    # system cannot cope with other PRSI classes
    if(employee["PRSI Class"] == "A"):

        if (weekly_salary <= 352):
            prsi = 0
        elif (weekly_salary > 352 and weekly_salary <= 424):
            prsi = weekly_salary * .04
            prsi_credit = (prsi_max_weekly_credit -
                           (weekly_salary - 352.01)/6)
            prsi -= prsi_credit
        else:
            # else gross weekly ovr 24
            prsi = weekly_salary * .04

    return prsi
# Employers pay 8.8% or 11.05% class A, over up $398

# Calculation week employer PRSI
def calculate_week_employer_PRSI_due(employee):
    weekly_salary = employee["Annual Salary"] / weeks_in_2021
    employer_prsi = 0

    if (weekly_salary > 398):
        # In this case the employers pay 11.05 class A over up $398
        employer_prsi = (weekly_salary - 398) * 1105
        # Employers pay 8.8% class A over up $398

    else:
        # Employers pay 8.8% class A on weekly earnings
        employer_prsi += weekly_salary * .088

    return employer_prsi

#Calculation annual usc
def calculate_annual_USC_due():

    pass

# Calculation employee usc
def calcule_employee_usc(employee):
    '''return weekly USC due by employee'''

    salary = employee["Annual Salary"]

    # no USC on earnings less than $13,000
    if salary < 13000:
        usc = 0
    else:
        # else first $12,012 => 0.5%
        usc = 12012 * .005
        salary -= 12012

    # $8,675 => 2%
    if salary < 8675:
        usc += salary * .02
    else:
        usc += 8675 * .02
        salary -= 8675
    # $49.357 => 4.5%
    if salary < 49357:
        usc += salary * .045
    else:
        usc += 49357 * .045
        salary -= 49357
    # rest => 8%
        usc += salary * .08
    usc /= weeks_in_2021

    return round(usc, 2)


print(
    f'Employee {emp1["First name"]} {emp1["Last name"]} Salary: €{emp1["Annual Salary"]:.2f}')
print("Tax liability: €" +
      "{:,.2f}".format(calculate_paye_tax_liabliity(emp1)))
print("Tax due: " + str(calculate_annual_tax_due(emp1)))
print(f"Employee weekly PRSI $ {calculate_week_employee_PRSI_due(emp1):,.2f}")
print(f"Employer weekly PRSI $ {calculate_week_employer_PRSI_due(emp1):,.2f}")
print(f"Employer USC {calcule_employee_usc(emp1):,.2f}")

# Main menu
def print_main_menu():
    print("\nPayslip system")
    print("Choose option:")
    print("\t1- View All employees in the system")
    print("\t2- Add new employee")
    print("\t3- Print payslip")
    print("\t4- Monthly payslip")
    print("\t5- Annual gross salary")
    print("\t6- Print all payslips")
    print("\t7- Exit")

#message when exiting the program
def quitApp():
    print("\n")
    print("-"*30)
    print("Thank you!!!")
    print("-"*30)
    print("\n")
    quit()

# Show all the employees saved in the system 
def all_employees_view(employees):
    print("\nEmployee details:  \n")
    num = 1
    for emp in employees:
        print("-"*30)
        name = f'{emp["First name"]} {emp["Last name"]}'
        print(f'{num} - Employee:  {name:<20}  \tAnnual Salary: ${emp["Annual Salary"]:>13,.2f}')
        print(f'PPS: {emp["PPS"]}')
        print("-"*30)
        num += 1

# Error messager
def print_invalid_option():
    print("\n")
    print("-"*60)
    print("Invalid option")
    print("-"*60)


def print_message(message):
    print("-"*30)
    print(message)
    print("-"*30)

# Add new employee in the system
def add_employee(employee_details):
    fname, lname, pps_number, personal_tax_amount, prsi_class, annual_salary = employee_details
    employee = {
        "First name": fname,
        "Last name": lname,
        "PPS": pps_number,
        "Tax Credit": personal_tax_amount,
        "PRSI Class": prsi_class,
        "Annual Salary": annual_salary,
    }
    employees.append(employee)

# Collect date of the new employee
def new_employee():

    first_name = ""
    while(True):
        first_name = input("First name: ").strip().capitalize()
        # condiction like string empty return false and the name need more than 2 leteeres
        if len(first_name) >= 2:
            print(first_name)
            break
        else:
            print_message("Not a valid first name!")

    last_name = ""
    while(True):
        last_name = input("Last name: ").strip().capitalize()

        if len(last_name) >= 2:
            print(last_name)
            break
        else:
            print_message("Not a valid last name!")

    pps = ""
    while(True):
        pps = input("Add de PPS number: ").strip().upper()

        if len(pps) == 9 and pps[:7].isdigit() and pps[-2].isalnum() and pps[-1].isalpha():
            break
        else:
            print_message(
                "Should be 8 digits followed by an alphabetic character")

    personal_tax_amount = 0
    while(True):

        try:
            personal_tax_amount = int(
                float(input("Add a personal tax credit: ").strip()))
            break
        except:
            print_message("Invalid input")

    prsi_class = "A"
    while(True):
        print("PRSI class must be A, B, S")
        prsi_class = input("Add PRSI class: ").capitalize()

        if (prsi_class in ["A", "B", "S"]):
            break
        else:
            print_message("Invalid PRSI class.")

    annual_salary = 0
    while(True):

        try:
            annual_salary = int(float(input("Add annual salary: ").strip()))
            break
        except:
            print_message("Invalid input")

# (fname,lname,pps_number,personal_tax_amount,prsi_class,annual_salary)
    return (first_name, last_name, pps, personal_tax_amount, prsi_class, annual_salary)

# print payslip 
#editar essedesign


def print_payslip_monthly(employee):
    usc = round(calcule_employee_usc(employee), 2)
    employee_prsi = round(calculate_week_employee_PRSI_due(employee), 2)
    employer_prsi = round(calculate_week_employer_PRSI_due(employee), 2)
    annual_tax_due = round(calculate_annual_tax_due(employee), 2)
    monthly_tax_due = round(annual_tax_due/12, 2)
    gross_salary = round(employee["Annual Salary"]/12, 2)
    total_debits = round(monthly_tax_due - employee_prsi  - usc, 2)
    net_salary = round(gross_salary + total_debits, 2)

    print("-"*60)
    print("#"*30)
    print("Company Name: Momo Ltd")
    print(f"USC:{usc}")
    # Get Date now
    today = datetime.date.today()
    # Format date mm/dd/yy
    date_formatted = today.strftime("%D/%m/%Y")
    print(f'Employee name: {employee["First name"]} {employee["Last name"]}')
    print(f"Date: {date_formatted}")
    print("#"*30)
    print(f"Employee PRSI: $ {employee_prsi}")
    print(f"Employer PRSI: $ {employer_prsi}")
    print(f"Annual TAX due: $ {annual_tax_due}")
    print(f"Monthly TAX due: $ {monthly_tax_due}")    
    print(f"GROSS Salary: $ {gross_salary}")
    print("#"*30)
    print(f"Total Deductions: $ {total_debits}")
    print(f"NET Salary: $ {net_salary}")
    print("#"*30)
    print("-"*60)

    
def print_month_payroll(employees):
    # Get Date now
    today = datetime.date.today()
    # Format date mm/dd/yy
    date_formatted = today.strftime("%m/%y")
    print(f'List of Employees wages this month ({date_formatted}):')
    totalWages = 0
    for emp in employees:
        monthlyGrossSalary = emp["Annual Salary"]/12
        print("-"*30)
        print(f'Employee name: {emp["First name"]} {emp["Last name"]} - Monthly Gross Salary - ${monthlyGrossSalary}')
        totalWages = totalWages + monthlyGrossSalary
        print("-"*30)
    print(f'Total wage this month({date_formatted}):  ${totalWages}')
    print("-"*30)

def print_annual_payroll(employees):
    # Get Date now
    today = datetime.date.today()
    # Format date mm/dd/yy
    date_formatted = today.strftime("%Y")
    print(f'List of Employees wages this year ({date_formatted}):')
    totalWages = 0
    for emp in employees:
        print("-"*30)
        annualGrossSalary = emp["Annual Salary"]
        print("-"*30)
        print(f'Employee name: {emp["First name"]} {emp["Last name"]} - Annual Gross Salary - ${annualGrossSalary}')
        totalWages = totalWages + annualGrossSalary
        print("-"*30)
    print(f'Total wage this year({date_formatted}):  ${totalWages}')


def all_payslips(employees):
    for emp in employees:
        print_payslip_monthly(emp)


# print_message("Payroll")


# Payroll system
def main():
    while(True):

        print_main_menu()
        option = input("\tChoose de option and press enter: ")

        if(option == "1"):
            all_employees_view(employees)
        elif(option == "2"):
            add_employee(new_employee())
        #Print payslips
        elif(option == "3"):
            print("List of employees: ")
            all_employees_view(employees)
            emp_num = int(input("Choose employee by number: "))
            try:
                print_payslip_monthly(employees[emp_num-1])
            except:
                print_invalid_option()
            
        elif(option == "4"):
            print_month_payroll(employees)
        elif(option == "5"):
            print_annual_payroll(employees)
        elif(option == "6"):
            all_payslips(employees)
        elif(option == "7"):
            quitApp()
        else:
            print_invalid_option()
# Run the procedure to start        
main()
