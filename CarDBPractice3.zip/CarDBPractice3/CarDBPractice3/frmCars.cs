﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDBPractice3
{
    // class Dog : Animal
    public partial class frmCars : Form
    {
        public frmCars()
        {
            InitializeComponent();
        }

        private void frmCars_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hireDataSet.tblCar' table. You can move, or remove it, as needed.
            this.tblCarTableAdapter.Fill(this.hireDataSet.tblCar);
            // Part 3
            // Set the Text property of the form frmCars
            // Task A your name and today's date
            this.Text = "Task A - Thomas Mc Cann - " + DateTime.Now.ToShortDateString();

            // Update the record display on load
            this.UpdateRecordDisplay();
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveFirst();
            this.UpdateRecordDisplay();
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MovePrevious();
            this.UpdateRecordDisplay();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveNext();
            this.UpdateRecordDisplay();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tblCarBindingSource.MoveLast();
            this.UpdateRecordDisplay();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Function to update the record display

        private void UpdateRecordDisplay()
        {
            // txtBxRecordCount.Text = tblCarBindingSource.Position.ToString();

            // txtBxRecordCount.Text = tblCarBindingSource.Count.ToString();


            // Get the position + 1 and the count of the total records from the bindingSource
            txtBxRecordCount.Text = (tblCarBindingSource.Position + 1) + " of " + tblCarBindingSource.Count;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Remove the current record (if there is a record to remove)
            if(tblCarBindingSource.Count > 0)
            {
                tblCarBindingSource.RemoveCurrent();
                this.UpdateRecordDisplay();
            }
            // Not actually required in the assignment but nice to do
            else
            {                
                MessageBox.Show("No record to delete.");
            }
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Add a new record
            tblCarBindingSource.AddNew();

            // Set the checked stat of the available checkbox to unchecked
            chkBxAvailable.CheckState = CheckState.Unchecked;

            this.UpdateRecordDisplay();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Cancel any edits
            tblCarBindingSource.CancelEdit();

            // Reject any changes made to the dataset
            // If move to another record any chnages made are commited o the dataset
            // NOT SURE IF WE NEED THIS
            hireDataSet.RejectChanges();

            this.UpdateRecordDisplay();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Push any current editing/changes to the data binding through to the DS
            tblCarBindingSource.EndEdit();

            // Using the TableAdpater update the database
            // with any changes made to the dataset 'hireDataSet'
            // Update method returns the count of the number of rows/record updated to the database
            int reocordsUpdatedCount = tblCarTableAdapter.Update(hireDataSet);

            MessageBox.Show($"The DB was updated. {reocordsUpdatedCount} records were updated.");
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //Create new frmSearch object
            frmSearch searchFrom = new frmSearch(this);

            // Show the form
            searchFrom.Show();

            // Hide this form 
            this.Hide();

        }
    }
}
