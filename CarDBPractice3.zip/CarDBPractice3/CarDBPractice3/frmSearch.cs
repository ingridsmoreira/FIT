﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarDBPractice3
{
    public partial class frmSearch : Form
    {
        private frmCars carForm;
        public frmSearch(frmCars carForm)
        {
            InitializeComponent();
            // Save the reference of the frmCars project that called this frmSeacrh form
            this.carForm = carForm;
        }

        private void frmSearch_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'hireDataSet.tblCar' table. You can move, or remove it, as needed.
            this.tblCarTableAdapter.Fill(this.hireDataSet.tblCar);

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
            // Show th calling form
            carForm.Show();
        }

        private void btnClose_Click(object sender, FormClosedEventArgs e)
        {

        }
    }
}
